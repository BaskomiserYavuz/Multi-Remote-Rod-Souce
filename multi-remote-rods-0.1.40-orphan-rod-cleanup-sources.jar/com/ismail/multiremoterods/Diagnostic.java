/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1536
 *  net.minecraft.class_1676
 *  net.minecraft.class_2338
 *  net.minecraft.class_238
 *  net.minecraft.class_2680
 *  net.minecraft.class_3218
 *  net.minecraft.class_7923
 */
package com.ismail.multiremoterods;

import com.ismail.multiremoterods.MultiRemoteRods;
import com.ismail.multiremoterods.RemoteBobberData;
import com.ismail.multiremoterods.RemoteRodState;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1536;
import net.minecraft.class_1676;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_7923;

public final class Diagnostic {
    private Diagnostic() {
    }

    public static void dumpRodContext(class_3218 contextWorld, UUID ownerUuid, UUID rodUuid, String phase) {
        RemoteRodState state = RemoteRodState.get(contextWorld);
        Optional<RemoteRodState.Entry> optionalEntry = state.getEntry(ownerUuid, rodUuid);
        MultiRemoteRods.LOGGER.warn("[MRR-DIAG:{}] rod={} owner={} currentDimension={} savedEntryPresent={}", new Object[]{phase, rodUuid, ownerUuid, contextWorld.method_27983().method_29177(), optionalEntry.isPresent()});
        Diagnostic.dumpAllLoadedBobbers(contextWorld, phase, ownerUuid, rodUuid);
        if (optionalEntry.isEmpty()) {
            MultiRemoteRods.LOGGER.warn("[MRR-DIAG:{}] No saved entry for rod={}", (Object)phase, (Object)rodUuid);
            return;
        }
        RemoteRodState.Entry entry = optionalEntry.get();
        class_3218 targetWorld = state.getWorldForEntry(contextWorld, entry);
        MultiRemoteRods.LOGGER.warn("[MRR-DIAG:{}] saved bobber={} dimension={} pos=({}, {}, {}) targetWorldLoaded={}", new Object[]{phase, entry.bobberUuid, entry.dimension, entry.x, entry.y, entry.z, targetWorld != null});
        if (targetWorld == null) {
            return;
        }
        class_1297 indexed = targetWorld.method_66347(entry.bobberUuid);
        MultiRemoteRods.LOGGER.warn("[MRR-DIAG:{}] UUID index lookup bobber={} result={}", new Object[]{phase, entry.bobberUuid, Diagnostic.describeEntity(indexed)});
        class_238 area = new class_238(entry.x - 2.5, entry.y - 2.5, entry.z - 2.5, entry.x + 2.5, entry.y + 2.5, entry.z + 2.5);
        List<class_1297> nearby = targetWorld.method_8333(null, area, entity -> true);
        MultiRemoteRods.LOGGER.warn("[MRR-DIAG:{}] entities within 2.5 blocks of saved position: count={}", (Object)phase, (Object)nearby.size());
        for (class_1297 entity2 : nearby) {
            MultiRemoteRods.LOGGER.warn("[MRR-DIAG:{}] nearby {}", (Object)phase, (Object)Diagnostic.describeEntity(entity2));
        }
        class_2338 center = class_2338.method_49637((double)entry.x, (double)entry.y, (double)entry.z);
        for (class_2338 pos : class_2338.method_10097((class_2338)center.method_10069(-2, -2, -2), (class_2338)center.method_10069(2, 2, 2))) {
            class_2680 blockState = targetWorld.method_8320(pos);
            String blockId = class_7923.field_41175.method_10221(blockState.method_26204()).toString();
            if (!blockId.contains("pressure_plate") && !blockId.contains("trapdoor")) continue;
            MultiRemoteRods.LOGGER.warn("[MRR-DIAG:{}] relevantBlock pos={} id={} state={}", new Object[]{phase, pos, blockId, blockState});
        }
    }

    public static void dumpAllLoadedBobbers(class_3218 contextWorld, String phase, UUID expectedOwner, UUID expectedRod) {
        int count = 0;
        for (class_3218 world : contextWorld.method_8503().method_3738()) {
            for (class_1297 entity : world.method_27909()) {
                if (!(entity instanceof class_1536)) continue;
                class_1536 bobber = (class_1536)entity;
                ++count;
                RemoteBobberData data = RemoteBobberData.of(bobber);
                Object[] objectArray = new Object[5];
                objectArray[0] = phase;
                objectArray[1] = world.method_27983().method_29177();
                objectArray[2] = Diagnostic.describeEntity((class_1297)bobber);
                objectArray[3] = data.multiremoterods$getOwnerUuid().filter(expectedOwner::equals).isPresent();
                objectArray[4] = data.multiremoterods$getRodUuid().filter(expectedRod::equals).isPresent();
                MultiRemoteRods.LOGGER.warn("[MRR-DIAG:{}] loadedBobber dimension={} {} expectedOwnerMatch={} expectedRodMatch={}", objectArray);
            }
        }
        MultiRemoteRods.LOGGER.warn("[MRR-DIAG:{}] total loaded fishing bobbers={}", (Object)phase, (Object)count);
    }

    public static String describeEntity(class_1297 entity) {
        if (entity == null) {
            return "null";
        }
        String ownerDescription = "n/a";
        if (entity instanceof class_1676) {
            class_1676 projectile = (class_1676)entity;
            class_1297 owner = projectile.method_24921();
            ownerDescription = owner == null ? "null" : owner.getClass().getSimpleName() + "#" + owner.method_5628() + "/" + String.valueOf(owner.method_5667());
        }
        String remoteDescription = "not-remote-data";
        if (entity instanceof class_1536) {
            class_1536 bobber = (class_1536)entity;
            RemoteBobberData data = RemoteBobberData.of(bobber);
            remoteDescription = "remote=" + data.multiremoterods$isRemotePersistent() + ",storedOwner=" + data.multiremoterods$getOwnerUuid().map(UUID::toString).orElse("null") + ",rod=" + data.multiremoterods$getRodUuid().map(UUID::toString).orElse("null") + ",allowRemoval=" + data.multiremoterods$allowRemoval();
        }
        return "type=" + String.valueOf(class_7923.field_41177.method_10221(entity.method_5864())) + ",class=" + entity.getClass().getName() + ",id=" + entity.method_5628() + ",uuid=" + String.valueOf(entity.method_5667()) + ",pos=" + String.valueOf(entity.method_73189()) + ",alive=" + entity.method_5805() + ",removed=" + entity.method_31481() + ",owner=" + ownerDescription + ",bbox=" + String.valueOf(entity.method_5829()) + "," + remoteDescription;
    }
}
