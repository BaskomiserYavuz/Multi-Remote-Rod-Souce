/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1299
 *  net.minecraft.class_1299$class_1300
 *  net.minecraft.class_1311
 *  net.minecraft.class_2378
 *  net.minecraft.class_2960
 *  net.minecraft.class_5321
 *  net.minecraft.class_7923
 *  net.minecraft.class_7924
 */
package com.ismail.multiremoterods;

import com.ismail.multiremoterods.entity.PersistentFishingBobberEntity;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class ModEntities {
    public static final class_2960 PERSISTENT_BOBBER_ID = class_2960.method_60655((String)"multiremoterods", (String)"persistent_fishing_bobber");
    public static final class_5321<class_1299<?>> PERSISTENT_BOBBER_KEY = class_5321.method_29179((class_5321)class_7924.field_41266, (class_2960)PERSISTENT_BOBBER_ID);
    public static final class_1299<PersistentFishingBobberEntity> PERSISTENT_BOBBER = class_2378.method_39197(class_7923.field_41177, PERSISTENT_BOBBER_KEY, class_1299.class_1300.method_5903(PersistentFishingBobberEntity::new, class_1311.field_17715).method_17687(0.25f, 0.25f).method_27299(4).method_27300(5).method_5905(PERSISTENT_BOBBER_KEY));

    private ModEntities() {
    }

    public static void register() {
    }
}
