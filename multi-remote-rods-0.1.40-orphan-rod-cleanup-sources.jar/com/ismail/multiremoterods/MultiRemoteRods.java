/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.ModInitializer
 *  net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.ismail.multiremoterods;

import com.ismail.multiremoterods.RemoteRodState;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class MultiRemoteRods
implements ModInitializer {
    public static final String MOD_ID = "multiremoterods";
    public static final Logger LOGGER = LoggerFactory.getLogger((String)"multiremoterods");

    public void onInitialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> RemoteRodState.get(server.method_30002()).processPendingRetrieves(server));
        LOGGER.info("Multi Remote Rods 0.1.28-rc1 loaded.");
    }
}

