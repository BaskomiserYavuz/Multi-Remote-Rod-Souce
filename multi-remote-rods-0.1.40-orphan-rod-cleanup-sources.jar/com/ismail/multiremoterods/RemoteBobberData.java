/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1536
 */
package com.ismail.multiremoterods;

import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_1536;

public interface RemoteBobberData {
    public void multiremoterods$setRemoteData(UUID var1, UUID var2);

    public Optional<UUID> multiremoterods$getOwnerUuid();

    public Optional<UUID> multiremoterods$getRodUuid();

    public boolean multiremoterods$isRemotePersistent();

    public void multiremoterods$setAllowRemoval(boolean var1);

    public boolean multiremoterods$allowRemoval();

    public static RemoteBobberData of(class_1536 bobber) {
        return (RemoteBobberData)bobber;
    }
}

