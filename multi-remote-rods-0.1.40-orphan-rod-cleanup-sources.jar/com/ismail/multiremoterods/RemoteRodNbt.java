/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1799
 *  net.minecraft.class_2487
 *  net.minecraft.class_2520
 *  net.minecraft.class_4844
 *  net.minecraft.class_9279
 *  net.minecraft.class_9334
 */
package com.ismail.multiremoterods;

import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_4844;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

public final class RemoteRodNbt {
    public static final String ROOT = "multiremoterods";
    public static final String ROD_UUID = "rod_uuid";

    private RemoteRodNbt() {
    }

    public static UUID getOrCreateRodUuid(class_1799 stack) {
        Optional<UUID> existing = RemoteRodNbt.getRodUuid(stack);
        if (existing.isPresent()) {
            return existing.get();
        }
        UUID uuid = UUID.randomUUID();
        class_2487 root = RemoteRodNbt.getRootCopy(stack);
        root.method_67494(ROD_UUID, class_4844.field_40825, uuid);
        RemoteRodNbt.setRoot(stack, root);
        return uuid;
    }

    public static Optional<UUID> getRodUuid(class_1799 stack) {
        class_2487 root = RemoteRodNbt.getRootCopy(stack);
        return root.method_67491(ROD_UUID, class_4844.field_40825);
    }

    private static class_2487 getRootCopy(class_1799 stack) {
        class_9279 component = (class_9279)stack.method_58695(class_9334.field_49628, (Object)class_9279.field_49302);
        class_2487 all = component.method_57461();
        return all.method_68568(ROOT).method_10553();
    }

    private static void setRoot(class_1799 stack, class_2487 root) {
        class_9279 component = (class_9279)stack.method_58695(class_9334.field_49628, (Object)class_9279.field_49302);
        class_2487 all = component.method_57461();
        all.method_10566(ROOT, (class_2520)root);
        stack.method_57379(class_9334.field_49628, class_9279.method_57456(all));
    }
}
