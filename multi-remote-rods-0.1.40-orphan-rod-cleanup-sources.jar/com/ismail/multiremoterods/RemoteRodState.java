/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  net.minecraft.class_10741
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1536
 *  net.minecraft.class_1657
 *  net.minecraft.class_1787
 *  net.minecraft.class_18
 *  net.minecraft.class_243
 *  net.minecraft.class_2487
 *  net.minecraft.class_2520
 *  net.minecraft.class_2960
 *  net.minecraft.class_3218
 *  net.minecraft.class_3417
 *  net.minecraft.class_3419
 *  net.minecraft.class_3468
 *  net.minecraft.class_4284
 *  net.minecraft.class_4844
 *  net.minecraft.class_5321
 *  net.minecraft.class_7924
 *  net.minecraft.server.MinecraftServer
 */
package com.ismail.multiremoterods;

import com.ismail.multiremoterods.MultiRemoteRods;
import com.ismail.multiremoterods.RemoteBobberData;
import com.ismail.multiremoterods.RemoteRodNbt;
import com.ismail.multiremoterods.mixin.FishingBobberEntityAccessor;
import com.mojang.serialization.Codec;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_10741;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1536;
import net.minecraft.class_1657;
import net.minecraft.class_1787;
import net.minecraft.class_1799;
import net.minecraft.class_18;
import net.minecraft.class_1923;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3230;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_4284;
import net.minecraft.class_4844;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;

public final class RemoteRodState
extends class_18 {
    private static final String STATE_ID = "multiremoterods_state";
    private static final Codec<RemoteRodState> CODEC = class_2487.field_25128.xmap(RemoteRodState::fromNbt, RemoteRodState::toNbt);
    private static final class_10741<RemoteRodState> TYPE = new class_10741("multiremoterods_state", RemoteRodState::new, CODEC, class_4284.field_45077);
    private final Map<UUID, Entry> entries = new HashMap<UUID, Entry>();
    private final Map<UUID, PendingRetrieve> pendingRetrieves = new HashMap<UUID, PendingRetrieve>();
    private static final int REGION_TICKING_RADIUS = 1;
    private static final int REGION_TICKET_LEVEL = 2;

    public static RemoteRodState get(class_3218 world) {
        class_3218 overworld = world.method_8503().method_30002();
        return (RemoteRodState)overworld.method_17983().method_17924(TYPE);
    }

    public Optional<Entry> getEntry(UUID ownerUuid, UUID rodUuid) {
        return Optional.ofNullable(this.entries.get(rodUuid));
    }

    public void put(UUID ownerUuid, UUID rodUuid, class_1536 bobber, class_3218 world) {
        this.update(ownerUuid, rodUuid, bobber, world);
    }

    public void update(UUID ownerUuid, UUID rodUuid, class_1536 bobber, class_3218 world) {
        class_243 pos = bobber.method_73189();
        this.entries.put(rodUuid, new Entry(bobber.method_5667(), world.method_27983().method_29177().toString(), pos.field_1352, pos.field_1351, pos.field_1350));
        this.method_80();
    }

    public void remove(UUID ownerUuid, UUID rodUuid) {
        if (this.entries.remove(rodUuid) != null) {
            this.method_80();
        }
    }

    public Optional<class_1536> findBobber(class_3218 contextWorld, UUID ownerUuid, UUID rodUuid) {
        class_1536 bobber;
        class_1536 bobber2;
        for (class_3218 world : contextWorld.method_8503().method_3738()) {
            for (class_1297 entity2 : world.method_27909()) {
                if (!(entity2 instanceof class_1536) || !(bobber2 = (class_1536)entity2).method_5805()) continue;
                RemoteBobberData data = RemoteBobberData.of(bobber2);
                if (data.multiremoterods$getRodUuid().filter(rodUuid::equals).isEmpty()) continue;
                data.multiremoterods$setRemoteData(ownerUuid, rodUuid);
                bobber2.method_7432((class_1297)contextWorld.method_8503().method_3760().method_14602(ownerUuid));
                this.update(ownerUuid, rodUuid, bobber2, world);
                return Optional.of(bobber2);
            }
        }
        Optional<Entry> optionalEntry = this.getEntry(ownerUuid, rodUuid);
        if (optionalEntry.isEmpty()) {
            return Optional.empty();
        }
        Entry entry = optionalEntry.get();
        class_3218 targetWorld = this.getWorldForEntry(contextWorld, entry);
        if (targetWorld == null) {
            return Optional.empty();
        }
        class_1297 entity2 = targetWorld.method_66347(entry.bobberUuid);
        if (entity2 instanceof class_1536 && (bobber2 = (class_1536)entity2).method_5805()) {
            RemoteBobberData.of(bobber2).multiremoterods$setRemoteData(ownerUuid, rodUuid);
            return Optional.of(bobber2);
        }
        int chunkX = (int)Math.floor(entry.x) >> 4;
        int chunkZ = (int)Math.floor(entry.z) >> 4;
        targetWorld.method_8497(chunkX, chunkZ);
        entity2 = targetWorld.method_66347(entry.bobberUuid);
        if (entity2 instanceof class_1536 && (bobber = (class_1536)entity2).method_5805()) {
            RemoteBobberData.of(bobber).multiremoterods$setRemoteData(ownerUuid, rodUuid);
            this.update(ownerUuid, rodUuid, bobber, targetWorld);
            return Optional.of(bobber);
        }
        for (class_1297 candidate : targetWorld.method_27909()) {
            class_1536 bobber3;
            if (!(candidate instanceof class_1536) || !(bobber3 = (class_1536)candidate).method_5805()) continue;
            RemoteBobberData data = RemoteBobberData.of(bobber3);
            if (data.multiremoterods$getRodUuid().filter(rodUuid::equals).isEmpty()) continue;
            data.multiremoterods$setRemoteData(ownerUuid, rodUuid);
            bobber3.method_7432((class_1297)contextWorld.method_8503().method_3760().method_14602(ownerUuid));
            this.update(ownerUuid, rodUuid, bobber3, targetWorld);
            MultiRemoteRods.LOGGER.info("Recovered remote bobber {} for rod {} by embedded UUID data", (Object)bobber3.method_5667(), (Object)rodUuid);
            return Optional.of(bobber3);
        }
        MultiRemoteRods.LOGGER.warn("Saved bobber {} for rod {} was not present after loading chunk {},{} in {}", new Object[]{entry.bobberUuid, rodUuid, chunkX, chunkZ, entry.dimension});
        return Optional.empty();
    }

    public void requestPendingRetrieve(UUID ownerUuid, UUID rodUuid, class_1268 hand) {
        this.pendingRetrieves.put(rodUuid, new PendingRetrieve(ownerUuid, hand, 100));
        MultiRemoteRods.LOGGER.info("Queued delayed remote-bobber lookup for rod {} (owner {}, hand {})", new Object[]{rodUuid, ownerUuid, hand});
    }

    public void processPendingRetrieves(MinecraftServer server) {
        if (this.pendingRetrieves.isEmpty()) {
            return;
        }
        var iterator = this.pendingRetrieves.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, PendingRetrieve> pendingEntry = iterator.next();
            UUID rodUuid = pendingEntry.getKey();
            PendingRetrieve pending = pendingEntry.getValue();
            if (--pending.ticksLeft <= 0) {
                MultiRemoteRods.LOGGER.warn("Timed out waiting for saved remote bobber for rod {}; mapping was preserved", (Object)rodUuid);
                iterator.remove();
                continue;
            }
            class_3222 player = server.method_3760().method_14602(pending.ownerUuid);
            if (player == null || player.method_31481()) continue;
            Optional<Entry> optionalEntry = this.getEntry(pending.ownerUuid, rodUuid);
            if (optionalEntry.isEmpty()) {
                iterator.remove();
                continue;
            }
            Entry entry = optionalEntry.get();
            class_3218 targetWorld = this.getWorldForEntry(server.method_30002(), entry);
            if (targetWorld == null) continue;
            int chunkX = (int)Math.floor(entry.x) >> 4;
            int chunkZ = (int)Math.floor(entry.z) >> 4;
            this.warmRemoteBobberArea(targetWorld, chunkX, chunkZ);
            class_1536 bobber = null;
            class_1297 indexed = targetWorld.method_66347(entry.bobberUuid);
            if (indexed instanceof class_1536 indexedBobber && indexedBobber.method_5805()) {
                bobber = indexedBobber;
            } else {
                for (class_1297 candidate : targetWorld.method_27909()) {
                    if (!(candidate instanceof class_1536 candidateBobber) || !candidateBobber.method_5805()) continue;
                    RemoteBobberData data = RemoteBobberData.of(candidateBobber);
                    if (data.multiremoterods$getRodUuid().filter(rodUuid::equals).isEmpty()) continue;
                    bobber = candidateBobber;
                    break;
                }
            }
            if (bobber == null) continue;
            RemoteBobberData data = RemoteBobberData.of(bobber);
            data.multiremoterods$setRemoteData(player.method_5667(), rodUuid);
            bobber.method_7432((class_1297)player);
            this.update(player.method_5667(), rodUuid, bobber, targetWorld);
            class_1799 heldStack = player.method_5998(pending.hand);
            boolean sameRodStillHeld = heldStack.method_7909() instanceof class_1787 && RemoteRodNbt.getRodUuid(heldStack).filter(rodUuid::equals).isPresent();
            if (!sameRodStillHeld) {
                MultiRemoteRods.LOGGER.info("Resolved delayed remote bobber {} for rod {}, but the rod is no longer in the original hand; next use will retrieve it", (Object)bobber.method_5667(), (Object)rodUuid);
                iterator.remove();
                continue;
            }
            data.multiremoterods$setAllowRemoval(true);
            int damage = ((FishingBobberEntityAccessor)bobber).multiremoterods$invokeUse(heldStack);
            heldStack.method_61653(damage, (class_1657)player);
            this.remove(player.method_5667(), rodUuid);
            player.method_7259(class_3468.field_15372.method_14956((class_1787)heldStack.method_7909()));
            player.method_51469().method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(), class_3417.field_15093, class_3419.field_15254, 1.0f, 0.4f / (player.method_59922().method_43057() * 0.4f + 0.8f));
            MultiRemoteRods.LOGGER.info("Completed delayed retrieval of remote bobber {} for rod {} from {}", new Object[]{bobber.method_5667(), rodUuid, entry.dimension});
            iterator.remove();
        }
    }

    public void warmRemoteBobberArea(class_3218 world, int centerChunkX, int centerChunkZ) {
        for (int dx = -REGION_TICKING_RADIUS; dx <= REGION_TICKING_RADIUS; ++dx) {
            for (int dz = -REGION_TICKING_RADIUS; dz <= REGION_TICKING_RADIUS; ++dz) {
                class_1923 chunkPos = new class_1923(centerChunkX + dx, centerChunkZ + dz);
                world.method_14178().method_66009(class_3230.field_54211, chunkPos, REGION_TICKET_LEVEL);
                world.method_8497(chunkPos.field_9181, chunkPos.field_9180);
            }
        }
    }

    public class_3218 getWorldForEntry(class_3218 contextWorld, Entry entry) {
        return contextWorld.method_8503().method_3847(class_5321.method_29179((class_5321)class_7924.field_41223, (class_2960)class_2960.method_60654((String)entry.dimension)));
    }

    private static class_2487 toNbt(RemoteRodState state) {
        class_2487 nbt = new class_2487();
        class_2487 all = new class_2487();
        for (Map.Entry<UUID, Entry> mapEntry : state.entries.entrySet()) {
            Entry entry = mapEntry.getValue();
            class_2487 tag = new class_2487();
            tag.method_67494("bobber", class_4844.field_40825, entry.bobberUuid);
            tag.method_10582("dimension", entry.dimension);
            tag.method_10549("x", entry.x);
            tag.method_10549("y", entry.y);
            tag.method_10549("z", entry.z);
            all.method_10566(mapEntry.getKey().toString(), (class_2520)tag);
        }
        nbt.method_10566("entries", (class_2520)all);
        return nbt;
    }

    private static RemoteRodState fromNbt(class_2487 nbt) {
        RemoteRodState state = new RemoteRodState();
        class_2487 all = nbt.method_68568("entries");
        for (String keyString : all.method_10541()) {
            try {
                class_2487 tag = all.method_68568(keyString);
                UUID bobberUuid = (UUID)tag.method_67491("bobber", class_4844.field_40825).orElseThrow(() -> new IllegalArgumentException("Missing bobber UUID"));
                String rodPart = keyString.contains(":") ? keyString.substring(keyString.lastIndexOf(58) + 1) : keyString;
                UUID rodUuid = UUID.fromString(rodPart);
                state.entries.put(rodUuid, new Entry(bobberUuid, tag.method_68564("dimension", "minecraft:overworld"), tag.method_68563("x", 0.0), tag.method_68563("y", 0.0), tag.method_68563("z", 0.0)));
            }
            catch (Exception ex) {
                MultiRemoteRods.LOGGER.warn("Skipping invalid remote rod entry {}", (Object)keyString, (Object)ex);
            }
        }
        return state;
    }

    public static final class Entry {
        public final UUID bobberUuid;
        public final String dimension;
        public final double x;
        public final double y;
        public final double z;

        public Entry(UUID bobberUuid, String dimension, double x, double y, double z) {
            this.bobberUuid = bobberUuid;
            this.dimension = dimension;
            this.x = x;
            this.y = y;
            this.z = z;
        }
    }

    private static final class PendingRetrieve {
        private final UUID ownerUuid;
        private final class_1268 hand;
        private int ticksLeft;

        private PendingRetrieve(UUID ownerUuid, class_1268 hand, int ticksLeft) {
            this.ownerUuid = ownerUuid;
            this.hand = hand;
            this.ticksLeft = ticksLeft;
        }
    }
}
