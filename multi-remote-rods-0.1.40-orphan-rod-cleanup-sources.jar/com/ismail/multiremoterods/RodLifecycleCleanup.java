package com.ismail.multiremoterods;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1536;
import net.minecraft.class_3218;

/**
 * Removes a persistent remote bobber when the physical rod that owns its UUID
 * is permanently destroyed or despawns as an item entity.
 *
 * This intentionally does not change the saved-state/NBT schema, so worlds
 * created with older Multi Remote Rods versions remain compatible.
 */
public final class RodLifecycleCleanup {
    private RodLifecycleCleanup() {
    }

    public static void cleanupDestroyedRod(class_3218 contextWorld, UUID rodUuid, String cause) {
        if (contextWorld == null || rodUuid == null) {
            return;
        }

        RemoteRodState state = RemoteRodState.get(contextWorld);
        Optional<RemoteRodState.Entry> savedEntry = state.getEntry(null, rodUuid);

        // If the mapping points to an unloaded/cross-dimensional bobber, load
        // the same small regional area the normal retrieval path already uses.
        if (savedEntry.isPresent()) {
            RemoteRodState.Entry entry = savedEntry.get();
            class_3218 targetWorld = state.getWorldForEntry(contextWorld, entry);
            if (targetWorld != null) {
                int chunkX = (int)Math.floor(entry.x) >> 4;
                int chunkZ = (int)Math.floor(entry.z) >> 4;
                state.warmRemoteBobberArea(targetWorld, chunkX, chunkZ);

                class_1297 indexed = targetWorld.method_66347(entry.bobberUuid);
                if (indexed instanceof class_1536 bobber && !bobber.method_31481()) {
                    removeBobber(bobber);
                }
            }
        }

        // Also scan currently loaded entities by the UUID embedded in the
        // bobber. This covers stale saved positions / recovered bobbers while
        // keeping the operation idempotent.
        List<class_1536> matchingBobbers = new ArrayList<>();
        for (class_3218 world : contextWorld.method_8503().method_3738()) {
            for (class_1297 entity : world.method_27909()) {
                if (!(entity instanceof class_1536 bobber) || bobber.method_31481()) {
                    continue;
                }
                RemoteBobberData data = RemoteBobberData.of(bobber);
                if (data.multiremoterods$getRodUuid().filter(rodUuid::equals).isPresent()) {
                    matchingBobbers.add(bobber);
                }
            }
        }
        for (class_1536 bobber : matchingBobbers) {
            removeBobber(bobber);
        }

        // Remove the persistent mapping last. No serialization format changes
        // are introduced; this is the same existing entry removal path used by
        // a normal rod retrieval.
        state.remove(null, rodUuid);

        if (savedEntry.isPresent() || !matchingBobbers.isEmpty()) {
            MultiRemoteRods.LOGGER.info(
                "Removed orphaned remote bobber for destroyed/despawned rod {} (cause={})",
                rodUuid,
                cause
            );
        }
    }

    private static void removeBobber(class_1536 bobber) {
        if (bobber.method_31481()) {
            return;
        }
        RemoteBobberData data = RemoteBobberData.of(bobber);
        data.multiremoterods$setAllowRemoval(true);
        bobber.method_5650(class_1297.class_5529.field_26999);
    }
}
