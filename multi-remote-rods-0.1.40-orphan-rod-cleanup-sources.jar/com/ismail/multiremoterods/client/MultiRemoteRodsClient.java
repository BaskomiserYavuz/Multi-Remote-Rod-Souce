/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.ClientModInitializer
 *  net.minecraft.class_1299
 *  net.minecraft.class_5617
 *  net.minecraft.class_906
 */
package com.ismail.multiremoterods.client;

import com.ismail.multiremoterods.ModEntities;
import com.ismail.multiremoterods.mixin.client.EntityRendererFactoriesAccessor;
import java.util.Map;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_1299;
import net.minecraft.class_5617;
import net.minecraft.class_906;

public final class MultiRemoteRodsClient
implements ClientModInitializer {
    public void onInitializeClient() {
        Map<class_1299<?>, class_5617<?>> typedFactories;
        Map<class_1299<?>, class_5617<?>> rawFactories = typedFactories = EntityRendererFactoriesAccessor.multiremoterods$getRendererFactories();
        class_5617 rawFactory = class_906::new;
        rawFactories.put(ModEntities.PERSISTENT_BOBBER, rawFactory);
    }
}

