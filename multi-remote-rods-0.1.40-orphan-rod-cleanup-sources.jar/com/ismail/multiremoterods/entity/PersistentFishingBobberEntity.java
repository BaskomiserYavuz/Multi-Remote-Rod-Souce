/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1299
 *  net.minecraft.class_1536
 *  net.minecraft.class_1657
 *  net.minecraft.class_1937
 *  net.minecraft.class_2596
 *  net.minecraft.class_2602
 *  net.minecraft.class_2604
 *  net.minecraft.class_3218
 *  net.minecraft.class_3222
 *  net.minecraft.class_3231
 */
package com.ismail.multiremoterods.entity;

import com.ismail.multiremoterods.ModEntities;
import com.ismail.multiremoterods.RemoteBobberData;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1536;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2604;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3231;

public final class PersistentFishingBobberEntity
extends class_1536 {
    public PersistentFishingBobberEntity(class_1299<? extends class_1536> type, class_1937 world) {
        super(type, world);
    }

    public static PersistentFishingBobberEntity cast(class_1657 player, class_1937 world, UUID ownerUuid, UUID rodUuid) {
        class_1536 vanillaTemplate = new class_1536(player, world, 0, 0);
        PersistentFishingBobberEntity bobber = new PersistentFishingBobberEntity(ModEntities.PERSISTENT_BOBBER, world);
        bobber.method_7432((class_1297)player);
        bobber.method_5808(vanillaTemplate.method_23317(), vanillaTemplate.method_23318(), vanillaTemplate.method_23321(), vanillaTemplate.method_36454(), vanillaTemplate.method_36455());
        bobber.method_18799(vanillaTemplate.method_18798());
        RemoteBobberData.of(bobber).multiremoterods$setRemoteData(ownerUuid, rodUuid);
        return bobber;
    }

    private void multiremoterods$rebindServerOwner() {
        class_1937 class_19372;
        RemoteBobberData data = RemoteBobberData.of(this);
        UUID ownerUuid = data.multiremoterods$getOwnerUuid().orElse(null);
        if (ownerUuid == null || !((class_19372 = this.method_73183()) instanceof class_3218)) {
            return;
        }
        class_3218 serverWorld = (class_3218)class_19372;
        class_3222 player = serverWorld.method_8503().method_3760().method_14602(ownerUuid);
        if (player != null && this.method_24921() != player) {
            this.method_7432((class_1297)player);
        }
    }

    public void method_5773() {
        if (!this.method_73183().method_8608()) {
            this.multiremoterods$rebindServerOwner();
        }
        super.method_5773();
    }

    public class_2596<class_2602> method_18002(class_3231 entityTrackerEntry) {
        this.multiremoterods$rebindServerOwner();
        return super.method_18002(entityTrackerEntry);
    }

    public void method_31471(class_2604 packet) {
        class_1297 possibleOwner;
        this.method_5838(packet.method_11167());
        this.method_5826(packet.method_11164());
        this.method_5808(packet.method_11175(), packet.method_11174(), packet.method_11176(), packet.method_11168(), packet.method_11171());
        this.method_18799(packet.method_73084());
        this.method_5847(packet.method_43233());
        int ownerId = packet.method_11166();
        if (ownerId > 0 && (possibleOwner = this.method_73183().method_8469(ownerId)) instanceof class_1657) {
            this.method_7432(possibleOwner);
        }
    }
}

