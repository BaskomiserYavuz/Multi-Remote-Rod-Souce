/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1297$class_5529
 *  net.minecraft.class_1536
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package com.ismail.multiremoterods.mixin;

import com.ismail.multiremoterods.RemoteBobberData;
import net.minecraft.class_1297;
import net.minecraft.class_1536;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_1297.class})
public abstract class EntityMixin {
    @Inject(method={"method_5650"}, at={@At(value="HEAD")}, cancellable=true)
    private void multiremoterods$keepPersistentRemoteBobbers(class_1297.class_5529 reason, CallbackInfo ci) {
        class_1297 self = (class_1297)(Object)this;
        if (!(self instanceof class_1536)) {
            return;
        }
        class_1536 bobber = (class_1536)self;
        RemoteBobberData data = RemoteBobberData.of(bobber);
        if (!data.multiremoterods$isRemotePersistent()) {
            return;
        }
        if (data.multiremoterods$allowRemoval()) {
            return;
        }
        if (reason == class_1297.class_5529.field_26999) {
            ci.cancel();
        }
    }
}
