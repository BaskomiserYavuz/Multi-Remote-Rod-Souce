/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1299
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package com.ismail.multiremoterods.mixin;

import net.minecraft.class_1299;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1299.class})
public abstract class EntityTypeMixin {
    @Inject(method={"method_5893"}, at={@At(value="HEAD")}, cancellable=true)
    private void multiremoterods$makeFishingBobbersSaveable(CallbackInfoReturnable<Boolean> cir) {
        if ((Object)this == class_1299.field_6103) {
            cir.setReturnValue(true);
        }
    }
}
