/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_11368
 *  net.minecraft.class_11372
 *  net.minecraft.class_1297
 *  net.minecraft.class_1536
 *  net.minecraft.class_1657
 *  net.minecraft.class_1937
 *  net.minecraft.class_2604
 *  net.minecraft.class_3218
 *  net.minecraft.class_3222
 *  net.minecraft.class_4844
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package com.ismail.multiremoterods.mixin;

import com.ismail.multiremoterods.RemoteBobberData;
import com.ismail.multiremoterods.RemoteRodState;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1297;
import net.minecraft.class_1536;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2604;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4844;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1536.class})
public abstract class FishingBobberEntityMixin
implements RemoteBobberData {
    @Unique
    private static final String MULTIREMOTERODS_DATA_KEY = "multiremoterods";
    @Unique
    private UUID multiremoterods$ownerUuid;
    @Unique
    private UUID multiremoterods$rodUuid;
    @Unique
    private boolean multiremoterods$persistentRemote;
    @Unique
    private boolean multiremoterods$allowRemoval;

    @Override
    public void multiremoterods$setRemoteData(UUID ownerUuid, UUID rodUuid) {
        this.multiremoterods$ownerUuid = ownerUuid;
        this.multiremoterods$rodUuid = rodUuid;
        this.multiremoterods$persistentRemote = true;
    }

    @Override
    public Optional<UUID> multiremoterods$getOwnerUuid() {
        return Optional.ofNullable(this.multiremoterods$ownerUuid);
    }

    @Override
    public Optional<UUID> multiremoterods$getRodUuid() {
        return Optional.ofNullable(this.multiremoterods$rodUuid);
    }

    @Override
    public boolean multiremoterods$isRemotePersistent() {
        return this.multiremoterods$persistentRemote;
    }

    @Override
    public void multiremoterods$setAllowRemoval(boolean allowRemoval) {
        this.multiremoterods$allowRemoval = allowRemoval;
    }

    @Override
    public boolean multiremoterods$allowRemoval() {
        return this.multiremoterods$allowRemoval;
    }

    @Inject(method={"method_5652"}, at={@At(value="TAIL")})
    private void multiremoterods$write(class_11372 view, CallbackInfo ci) {
        if (!this.multiremoterods$persistentRemote) {
            return;
        }
        class_11372 tag = view.method_71461(MULTIREMOTERODS_DATA_KEY);
        tag.method_71477("owner", class_4844.field_40825, this.multiremoterods$ownerUuid);
        tag.method_71477("rod", class_4844.field_40825, this.multiremoterods$rodUuid);
        tag.method_71472("persistent", true);
    }

    @Inject(method={"method_5749"}, at={@At(value="TAIL")})
    private void multiremoterods$read(class_11368 view, CallbackInfo ci) {
        Optional optionalTag = view.method_71420(MULTIREMOTERODS_DATA_KEY);
        if (optionalTag.isEmpty()) {
            return;
        }
        class_11368 tag = (class_11368)optionalTag.get();
        this.multiremoterods$ownerUuid = tag.method_71426("owner", class_4844.field_40825).orElse(null);
        this.multiremoterods$rodUuid = tag.method_71426("rod", class_4844.field_40825).orElse(null);
        this.multiremoterods$persistentRemote = tag.method_71433("persistent", false);
    }

    @Inject(method={"method_5773"}, at={@At(value="HEAD")}, cancellable=true)
    private void multiremoterods$rebindRuntimeOwnerBeforeTick(CallbackInfo ci) {
        class_3222 onlyPlayer;
        List players;
        class_3222 player;
        class_1657 currentOwner;
        if (!this.multiremoterods$persistentRemote || this.multiremoterods$rodUuid == null) {
            return;
        }
        Object selfObject = this;
        if (!(selfObject instanceof class_1536)) {
            return;
        }
        class_1536 self = (class_1536)selfObject;
        class_1937 class_19372 = self.method_73183();
        if (!(class_19372 instanceof class_3218)) {
            return;
        }
        class_3218 serverWorld = (class_3218)class_19372;
        class_1297 class_12972 = self.method_24921();
        if (class_12972 instanceof class_1657 && (currentOwner = (class_1657)class_12972).method_5805() && !currentOwner.method_31481()) {
            return;
        }
        class_3222 class_32222 = player = this.multiremoterods$ownerUuid == null ? null : serverWorld.method_8503().method_3760().method_14602(this.multiremoterods$ownerUuid);
        if ((player == null || !player.method_5805() || player.method_31481()) && (players = serverWorld.method_8503().method_3760().method_14571()).size() == 1 && (onlyPlayer = (class_3222)players.getFirst()).method_5805() && !onlyPlayer.method_31481()) {
            player = onlyPlayer;
        }
        if (player != null && player.method_5805() && !player.method_31481()) {
            this.multiremoterods$ownerUuid = player.method_5667();
            self.method_7432((class_1297)player);
            RemoteRodState.get(serverWorld).update(player.method_5667(), this.multiremoterods$rodUuid, self, serverWorld);
            return;
        }
        ci.cancel();
    }

    @Inject(method={"method_5773"}, at={@At(value="TAIL")})
    private void multiremoterods$saveCurrentPhysicalPosition(CallbackInfo ci) {
        class_1536 bobber;
        class_1937 class_19372;
        if (!this.multiremoterods$persistentRemote) {
            return;
        }
        if (this.multiremoterods$ownerUuid == null || this.multiremoterods$rodUuid == null) {
            return;
        }
        Object self = this;
        if (self instanceof class_1536 && (class_19372 = (bobber = (class_1536)self).method_73183()) instanceof class_3218) {
            class_3218 serverWorld = (class_3218)class_19372;
            RemoteRodState.get(serverWorld).update(this.multiremoterods$ownerUuid, this.multiremoterods$rodUuid, bobber, serverWorld);
        }
    }

    @Inject(method={"method_6959"}, at={@At(value="HEAD")}, cancellable=true)
    private void multiremoterods$doNotInvalidatePersistentRemote(class_1657 player, CallbackInfoReturnable<Boolean> cir) {
        if (this.multiremoterods$persistentRemote) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method={"method_31471"}, at={@At(value="HEAD")}, cancellable=true)
    private void multiremoterods$acceptOwnerLateSpawn(class_2604 packet, CallbackInfo ci) {
        class_1297 owner;
        Object selfObject = this;
        if (!(selfObject instanceof class_1536)) {
            return;
        }
        class_1536 self = (class_1536)selfObject;
        int ownerId = packet.method_11166();
        class_1297 class_12972 = owner = ownerId > 0 ? self.method_73183().method_8469(ownerId) : null;
        if (owner instanceof class_1657) {
            return;
        }
        self.method_5838(packet.method_11167());
        self.method_5826(packet.method_11164());
        self.method_5808(packet.method_11175(), packet.method_11174(), packet.method_11176(), packet.method_11168(), packet.method_11171());
        self.method_18799(packet.method_73084());
        self.method_5847(packet.method_43233());
        ci.cancel();
    }
}
