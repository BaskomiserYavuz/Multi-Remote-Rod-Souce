/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1269
 *  net.minecraft.class_1297
 *  net.minecraft.class_1536
 *  net.minecraft.class_1657
 *  net.minecraft.class_1787
 *  net.minecraft.class_1799
 *  net.minecraft.class_1937
 *  net.minecraft.class_3218
 *  net.minecraft.class_3222
 *  net.minecraft.class_3417
 *  net.minecraft.class_3419
 *  net.minecraft.class_3468
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package com.ismail.multiremoterods.mixin;

import com.ismail.multiremoterods.RemoteBobberData;
import com.ismail.multiremoterods.RemoteRodNbt;
import com.ismail.multiremoterods.RemoteRodState;
import com.ismail.multiremoterods.mixin.FishingBobberEntityAccessor;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1536;
import net.minecraft.class_1657;
import net.minecraft.class_1787;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1787.class})
public abstract class FishingRodItemMixin {
    @Inject(method={"method_7836"}, at={@At(value="HEAD")}, cancellable=true)
    private void multiremoterods$use(class_1937 world, class_1657 user, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        class_3218 serverWorld;
        class_1799 stack;
        block7: {
            block6: {
                stack = user.method_5998(hand);
                if (world.method_8608()) {
                    cir.setReturnValue(class_1269.field_5812);
                    return;
                }
                if (!(world instanceof class_3218)) break block6;
                serverWorld = (class_3218)world;
                if (user instanceof class_3222) break block7;
            }
            cir.setReturnValue(class_1269.field_5811);
            return;
        }
        class_3222 serverPlayer = (class_3222)user;
        UUID rodUuid = RemoteRodNbt.getOrCreateRodUuid(stack);
        UUID ownerUuid = serverPlayer.method_5667();
        RemoteRodState state = RemoteRodState.get(serverWorld);
        Optional<class_1536> existing = state.findBobber(serverWorld, ownerUuid, rodUuid);
        if (existing.isPresent() && existing.get().method_5805()) {
            class_1536 bobber = existing.get();
            class_1937 bobberWorld = bobber.method_73183();
            if (bobberWorld instanceof class_3218) {
                state.warmRemoteBobberArea((class_3218)bobberWorld, bobber.method_31476().field_9181, bobber.method_31476().field_9180);
            }
            bobber.method_7432((class_1297)serverPlayer);
            RemoteBobberData.of(bobber).multiremoterods$setAllowRemoval(true);
            int damage = ((FishingBobberEntityAccessor)bobber).multiremoterods$invokeUse(stack);
            stack.method_61653(damage, (class_1657)serverPlayer);
            state.remove(ownerUuid, rodUuid);
            user.method_7259(class_3468.field_15372.method_14956((class_1787)(Object)this));
            world.method_43128(null, user.method_23317(), user.method_23318(), user.method_23321(), class_3417.field_15093, class_3419.field_15254, 1.0f, 0.4f / (world.method_8409().method_43057() * 0.4f + 0.8f));
            cir.setReturnValue(class_1269.field_5812);
            return;
        }
        if (state.getEntry(ownerUuid, rodUuid).isPresent()) {
            state.requestPendingRetrieve(ownerUuid, rodUuid, hand);
            cir.setReturnValue(class_1269.field_5812);
            return;
        }
        class_1536 bobber = new class_1536((class_1657)serverPlayer, world, 0, 0);
        RemoteBobberData.of(bobber).multiremoterods$setRemoteData(ownerUuid, rodUuid);
        world.method_8649((class_1297)bobber);
        state.put(ownerUuid, rodUuid, bobber, serverWorld);
        world.method_43128(null, user.method_23317(), user.method_23318(), user.method_23321(), class_3417.field_14596, class_3419.field_15254, 0.5f, 0.4f / (world.method_8409().method_43057() * 0.4f + 0.8f));
        user.method_7259(class_3468.field_15372.method_14956((class_1787)(Object)this));
        cir.setReturnValue(class_1269.field_5812);
    }
}
