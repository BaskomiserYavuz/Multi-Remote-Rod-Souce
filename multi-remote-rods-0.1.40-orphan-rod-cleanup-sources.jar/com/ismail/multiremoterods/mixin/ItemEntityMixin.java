package com.ismail.multiremoterods.mixin;

import com.ismail.multiremoterods.RemoteRodNbt;
import com.ismail.multiremoterods.RodLifecycleCleanup;
import java.util.UUID;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1787;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1542.class})
public abstract class ItemEntityMixin {
    @Unique
    private UUID multiremoterods$tickRodUuid;
    @Unique
    private UUID multiremoterods$damageRodUuid;

    @Inject(method={"method_5773"}, at={@At(value="HEAD")})
    private void multiremoterods$captureRodBeforeItemTick(CallbackInfo ci) {
        class_1542 self = (class_1542)(Object)this;
        if (!(self.method_73183() instanceof class_3218)) {
            this.multiremoterods$tickRodUuid = null;
            return;
        }
        this.multiremoterods$tickRodUuid = multiremoterods$getRemoteRodUuid(self.method_6983());
    }

    @Inject(method={"method_5773"}, at={@At(value="TAIL")})
    private void multiremoterods$cleanupRodAfterItemTick(CallbackInfo ci) {
        class_1542 self = (class_1542)(Object)this;
        UUID rodUuid = this.multiremoterods$tickRodUuid;
        this.multiremoterods$tickRodUuid = null;
        if (rodUuid == null || !self.method_31481()) {
            return;
        }
        class_1297.class_5529 reason = self.method_35049();
        if (reason != class_1297.class_5529.field_26998 && reason != class_1297.class_5529.field_26999) {
            return;
        }
        class_1937 world = self.method_73183();
        if (world instanceof class_3218 serverWorld) {
            RodLifecycleCleanup.cleanupDestroyedRod(serverWorld, rodUuid, "item-tick/" + String.valueOf(reason));
        }
    }

    @Inject(method={"method_64397"}, at={@At(value="HEAD")})
    private void multiremoterods$captureRodBeforeDamage(class_3218 world, class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        class_1542 self = (class_1542)(Object)this;
        this.multiremoterods$damageRodUuid = multiremoterods$getRemoteRodUuid(self.method_6983());
    }

    @Inject(method={"method_64397"}, at={@At(value="RETURN")})
    private void multiremoterods$cleanupRodAfterDamage(class_3218 world, class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        class_1542 self = (class_1542)(Object)this;
        UUID rodUuid = this.multiremoterods$damageRodUuid;
        this.multiremoterods$damageRodUuid = null;
        if (rodUuid == null || !self.method_31481()) {
            return;
        }
        class_1297.class_5529 reason = self.method_35049();
        if (reason != class_1297.class_5529.field_26998 && reason != class_1297.class_5529.field_26999) {
            return;
        }
        RodLifecycleCleanup.cleanupDestroyedRod(world, rodUuid, "item-damage/" + String.valueOf(reason));
    }

    @Unique
    private static UUID multiremoterods$getRemoteRodUuid(class_1799 stack) {
        if (stack == null || !(stack.method_7909() instanceof class_1787)) {
            return null;
        }
        return RemoteRodNbt.getRodUuid(stack).orElse(null);
    }
}
