/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297$class_5529
 *  net.minecraft.class_1536
 *  net.minecraft.class_1657
 *  org.jetbrains.annotations.Nullable
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package com.ismail.multiremoterods.mixin;

import com.ismail.multiremoterods.RemoteBobberData;
import net.minecraft.class_1297;
import net.minecraft.class_1536;
import net.minecraft.class_1657;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_1657.class})
public abstract class PlayerEntityMixin {
    @Shadow
    @Nullable
    public class_1536 field_7513;

    @Inject(method={"method_5650"}, at={@At(value="HEAD")})
    private void multiremoterods$detachPersistentRemoteBobberOnPlayerRemove(class_1297.class_5529 reason, CallbackInfo ci) {
        if (this.field_7513 != null && RemoteBobberData.of(this.field_7513).multiremoterods$isRemotePersistent()) {
            this.field_7513 = null;
        }
    }
}

