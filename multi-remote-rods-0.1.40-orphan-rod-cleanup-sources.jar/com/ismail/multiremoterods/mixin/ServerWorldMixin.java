/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1536
 *  net.minecraft.class_3218
 *  net.minecraft.class_3222
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package com.ismail.multiremoterods.mixin;

import com.ismail.multiremoterods.MultiRemoteRods;
import com.ismail.multiremoterods.RemoteBobberData;
import com.ismail.multiremoterods.RemoteRodState;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1536;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_3218.class})
public abstract class ServerWorldMixin {
    @Inject(method={"method_18213"}, at={@At(value="HEAD")})
    private void multiremoterods$repairRemoteBobberOwners(class_3222 player, CallbackInfo ci) {
        this.multiremoterods$reattachAll(player, "join/restart");
    }

    @Inject(method={"method_18215"}, at={@At(value="TAIL")})
    private void multiremoterods$repairRemoteBobberOwnersAfterRespawn(class_3222 player, CallbackInfo ci) {
        this.multiremoterods$reattachAll(player, "death/respawn");
    }

    @Unique
    private void multiremoterods$reattachAll(class_3222 player, String cause) {
        class_3218 joiningWorld = (class_3218)(Object)this;
        for (class_3218 world : joiningWorld.method_8503().method_3738()) {
            for (class_1297 entity : world.method_27909()) {
                class_1536 bobber;
                RemoteBobberData data;
                if (!(entity instanceof class_1536) || !(data = RemoteBobberData.of(bobber = (class_1536)entity)).multiremoterods$isRemotePersistent()) continue;
                data.multiremoterods$getRodUuid().ifPresent(rodUuid -> {
                    data.multiremoterods$setRemoteData(player.method_5667(), (UUID)rodUuid);
                    bobber.method_7432((class_1297)player);
                    RemoteRodState.get(world).update(player.method_5667(), (UUID)rodUuid, bobber, world);
                    MultiRemoteRods.LOGGER.info("Reattached remote bobber {} to owner {} via rod {} after {}", new Object[]{bobber.method_5667(), player.method_5667(), rodUuid, cause});
                });
            }
        }
    }
}
