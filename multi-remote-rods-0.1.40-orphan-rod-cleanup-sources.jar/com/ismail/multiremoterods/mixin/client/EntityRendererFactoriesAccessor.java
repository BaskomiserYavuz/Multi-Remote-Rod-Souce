/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1299
 *  net.minecraft.class_5617
 *  net.minecraft.class_5619
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.gen.Accessor
 */
package com.ismail.multiremoterods.mixin.client;

import java.util.Map;
import net.minecraft.class_1299;
import net.minecraft.class_5617;
import net.minecraft.class_5619;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_5619.class})
public interface EntityRendererFactoriesAccessor {
    @Accessor(value="field_27768")
    public static Map<class_1299<?>, class_5617<?>> multiremoterods$getRendererFactories() {
        throw new AssertionError();
    }
}

